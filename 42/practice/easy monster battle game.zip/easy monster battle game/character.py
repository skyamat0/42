class character_property():
	def __init__(self, name, hp, mp, attack):
		self.name 	= name
		self.mp 	= mp
		self.hp 	= hp
		self.attack = attack

