from character import character_property

class protagonist(character_property):
	def action(self, e_hp: int, command: str) -> str:
		if command == "attack":
			e_hp -= self.attack
			print(f"{self.name} attack to enemy!")
			print(f"enemy got damaged {self.attack}!")
			return e_hp
