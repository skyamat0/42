def name_input() -> str:
	print("what is your name??:", end=" ")
	name = input()
	return (name)

def is_command(command: str) -> bool:
	commands = ["attack", "magic", "defense"]
	if command in commands:
		return (True)
	else:
		print("!!!type correct command!!!")
		return (False)
